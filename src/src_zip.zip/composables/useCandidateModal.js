import { ref } from "vue";
const isCandidateModalOpen = ref(false);
export default isCandidateModalOpen;
