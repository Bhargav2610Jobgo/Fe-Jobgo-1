import { ref } from "vue";

const conversationSummary = ref(null);



export default () => {
  return {
    conversationSummary,
  };
};
